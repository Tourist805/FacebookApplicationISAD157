﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace facebook_databaseISAD157
{
    class Database
    {
        //"server=proj-mysql.uopnet.plymouth.ac.uk;username=ISAD157_ZDauletov;password=ISAD157_22227450;database=isad157_zdauletov"
        // There we put our variables in order to connect with our database
        // to connect with database we need server name, user name or user id, database name and create a variable
        // connection to connect a database
        private const string USER_NAME = "ISAD157_ZDauletov";
        private const string SERVER = "proj-mysql.uopnet.plymouth.ac.uk";
        private const string DATABASE_NAME = "isad157_zdauletov";
        private const string PASSWORD = "ISAD157_22227450";
        private const string SslMode = "none";
        public static MySqlConnection connection_DB = new MySqlConnection();

        // Create a function which will inintialize our database when we load our project
        public static void Initialize_DataBase()
        {
            // create a variable myDDbulder which will be string with our data above
            MySqlConnectionStringBuilder myDBbuilder = new MySqlConnectionStringBuilder();
            myDBbuilder.Server = SERVER;
            myDBbuilder.UserID = USER_NAME;
            myDBbuilder.Database = DATABASE_NAME;
            myDBbuilder.Password = PASSWORD;

            String connection_str = myDBbuilder.ToString();

            myDBbuilder = null;

            Console.WriteLine(connection_str);
            // we put in our connectin_DB variable a string connection string to load our database

            connection_DB = new MySqlConnection(connection_str);
        }
        
        public MySqlConnection getSqlconnection()
        {
            return connection_DB;
        }
        public void openConnection()
        {
            if(connection_DB.State == System.Data.ConnectionState.Closed)
            {
                connection_DB.Open();
            }
        }
        public void closedConnection()
        {
            if (connection_DB.State == System.Data.ConnectionState.Open)
            {
                connection_DB.Close();
            }
        }
    }
}
