﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace facebook_databaseISAD157
{
    public partial class Formentry : Form
    {
       
        public String First_name, Last_name, Gender, Hometown, City;
        public int Number = 5001;
        public string idtemp;
        private void btnregister_Click(object sender, EventArgs e)
        {
            Form_Register form_Register = new Form_Register();
            form_Register.Show();
            this.Hide();
        }


        public Formentry()
        {
            InitializeComponent();
            Database.Initialize_DataBase();
        }
        public void Openformuserpage()
        {
            this.Hide();
            Formuserpage formUser = new Formuserpage();
            formUser.user_id = this.txtuser_id.Text;
            formUser.user_idname = this.txtfirstname.Text;
            formUser.user_idlastname = this.txtlastname.Text;
            formUser.Show();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            bool t = true;
            idtemp = txtuser_id.Text;
            String User_id = txtuser_id.Text;
            String First_name = txtfirstname.Text;
            String Last_name = txtlastname.Text;
            String query = String.Format("SELECT * FROM facebook_users WHERE user_id='{0}' AND first_name='{1}' AND last_name='{2}'",User_id, First_name, Last_name);
            Database.connection_DB.Open();
            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Formuserpage formUser = new Formuserpage();
            Formentry formnow = new Formentry();
            MySqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    int id = (int)reader["user_id"];
                    First_name = reader["first_name"].ToString();
                    Last_name = reader["last_name"].ToString();
                    Gender = reader["gender"].ToString();
                    Hometown = reader["hometown"].ToString();
                    City = reader["city"].ToString();
                    
                }
                MessageBox.Show("You were found " + "you name is : " + First_name + " your last name is : " + Last_name + " you live in " + City);

                t = true;
            }
            else
            {
                t = false;
            }
            
            reader.Close();
            Database.connection_DB.Close();
            if (t == true)
            {
                Openformuserpage();
            }
            else
            {
                MessageBox.Show("Data not found, please check your user_id or first name or last name");
            }

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        

        private void btngotodatabase_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormDB formdb = new FormDB();
            formdb.Show();
           
        }
    }
}
