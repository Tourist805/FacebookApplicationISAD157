﻿namespace facebook_databaseISAD157
{
    partial class FormDB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtuser_id = new System.Windows.Forms.TextBox();
            this.txtfirst_name = new System.Windows.Forms.TextBox();
            this.txtlast_name = new System.Windows.Forms.TextBox();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.txthometown = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.btninsertrow = new System.Windows.Forms.Button();
            this.btnupdaterow = new System.Windows.Forms.Button();
            this.btndeleterow = new System.Windows.Forms.Button();
            this.lstviewUsers = new System.Windows.Forms.ListView();
            this.column_userid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_First_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_last_name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_Gender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_Hometown = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.column_City = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnload_all = new System.Windows.Forms.Button();
            this.btnshowformlog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(125, 259);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "User ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(102, 291);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "First name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(102, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Last name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(129, 361);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(102, 398);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Hometown";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(157, 434);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "City";
            // 
            // txtuser_id
            // 
            this.txtuser_id.Location = new System.Drawing.Point(219, 257);
            this.txtuser_id.Name = "txtuser_id";
            this.txtuser_id.Size = new System.Drawing.Size(60, 22);
            this.txtuser_id.TabIndex = 7;
            // 
            // txtfirst_name
            // 
            this.txtfirst_name.Location = new System.Drawing.Point(219, 291);
            this.txtfirst_name.Name = "txtfirst_name";
            this.txtfirst_name.Size = new System.Drawing.Size(161, 22);
            this.txtfirst_name.TabIndex = 8;
            // 
            // txtlast_name
            // 
            this.txtlast_name.Location = new System.Drawing.Point(219, 326);
            this.txtlast_name.Name = "txtlast_name";
            this.txtlast_name.Size = new System.Drawing.Size(161, 22);
            this.txtlast_name.TabIndex = 9;
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(219, 361);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(60, 22);
            this.txtgender.TabIndex = 10;
            // 
            // txthometown
            // 
            this.txthometown.Location = new System.Drawing.Point(219, 398);
            this.txthometown.Name = "txthometown";
            this.txthometown.Size = new System.Drawing.Size(304, 22);
            this.txthometown.TabIndex = 11;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(219, 431);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(304, 22);
            this.txtcity.TabIndex = 12;
            // 
            // btninsertrow
            // 
            this.btninsertrow.Location = new System.Drawing.Point(230, 515);
            this.btninsertrow.Name = "btninsertrow";
            this.btninsertrow.Size = new System.Drawing.Size(85, 30);
            this.btninsertrow.TabIndex = 14;
            this.btninsertrow.Text = "Insert";
            this.btninsertrow.UseVisualStyleBackColor = true;
            this.btninsertrow.Click += new System.EventHandler(this.btninsertrow_Click);
            // 
            // btnupdaterow
            // 
            this.btnupdaterow.Location = new System.Drawing.Point(352, 515);
            this.btnupdaterow.Name = "btnupdaterow";
            this.btnupdaterow.Size = new System.Drawing.Size(85, 30);
            this.btnupdaterow.TabIndex = 15;
            this.btnupdaterow.Text = "Update";
            this.btnupdaterow.UseVisualStyleBackColor = true;
            this.btnupdaterow.Click += new System.EventHandler(this.btnupdaterow_Click);
            // 
            // btndeleterow
            // 
            this.btndeleterow.Location = new System.Drawing.Point(505, 515);
            this.btndeleterow.Name = "btndeleterow";
            this.btndeleterow.Size = new System.Drawing.Size(85, 30);
            this.btndeleterow.TabIndex = 16;
            this.btndeleterow.Text = "Delete";
            this.btndeleterow.UseVisualStyleBackColor = true;
            this.btndeleterow.Click += new System.EventHandler(this.btndeleterow_Click);
            // 
            // lstviewUsers
            // 
            this.lstviewUsers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.column_userid,
            this.column_First_name,
            this.column_last_name,
            this.column_Gender,
            this.column_Hometown,
            this.column_City});
            this.lstviewUsers.HideSelection = false;
            this.lstviewUsers.Location = new System.Drawing.Point(12, 2);
            this.lstviewUsers.Name = "lstviewUsers";
            this.lstviewUsers.Size = new System.Drawing.Size(995, 249);
            this.lstviewUsers.TabIndex = 17;
            this.lstviewUsers.UseCompatibleStateImageBehavior = false;
            this.lstviewUsers.View = System.Windows.Forms.View.Details;
            this.lstviewUsers.SelectedIndexChanged += new System.EventHandler(this.lstviewUsers_SelectedIndexChanged);
            // 
            // column_userid
            // 
            this.column_userid.Text = "User_id";
            // 
            // column_First_name
            // 
            this.column_First_name.Text = "First_Name";
            // 
            // column_last_name
            // 
            this.column_last_name.Text = "Last_name";
            // 
            // column_Gender
            // 
            this.column_Gender.Text = "Gender";
            // 
            // column_Hometown
            // 
            this.column_Hometown.Text = "Hometown";
            // 
            // column_City
            // 
            this.column_City.Text = "City";
            // 
            // btnload_all
            // 
            this.btnload_all.Location = new System.Drawing.Point(106, 515);
            this.btnload_all.Name = "btnload_all";
            this.btnload_all.Size = new System.Drawing.Size(85, 30);
            this.btnload_all.TabIndex = 18;
            this.btnload_all.Text = "Load all";
            this.btnload_all.UseVisualStyleBackColor = true;
            this.btnload_all.Click += new System.EventHandler(this.btnload_all_Click);
            // 
            // btnshowformlog
            // 
            this.btnshowformlog.Location = new System.Drawing.Point(889, 587);
            this.btnshowformlog.Name = "btnshowformlog";
            this.btnshowformlog.Size = new System.Drawing.Size(161, 30);
            this.btnshowformlog.TabIndex = 19;
            this.btnshowformlog.Text = "Go Back to the menu";
            this.btnshowformlog.UseVisualStyleBackColor = true;
            this.btnshowformlog.Click += new System.EventHandler(this.btnshowformlog_Click);
            // 
            // FormDB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1076, 643);
            this.Controls.Add(this.btnshowformlog);
            this.Controls.Add(this.btnload_all);
            this.Controls.Add(this.lstviewUsers);
            this.Controls.Add(this.btndeleterow);
            this.Controls.Add(this.btnupdaterow);
            this.Controls.Add(this.btninsertrow);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txthometown);
            this.Controls.Add(this.txtgender);
            this.Controls.Add(this.txtlast_name);
            this.Controls.Add(this.txtfirst_name);
            this.Controls.Add(this.txtuser_id);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormDB";
            this.Text = "FormDB";
            this.Load += new System.EventHandler(this.FormDB_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtuser_id;
        private System.Windows.Forms.TextBox txtfirst_name;
        private System.Windows.Forms.TextBox txtlast_name;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.TextBox txthometown;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.Button btninsertrow;
        private System.Windows.Forms.Button btnupdaterow;
        private System.Windows.Forms.Button btndeleterow;
        private System.Windows.Forms.ListView lstviewUsers;
        private System.Windows.Forms.ColumnHeader column_userid;
        private System.Windows.Forms.ColumnHeader column_First_name;
        private System.Windows.Forms.ColumnHeader column_last_name;
        private System.Windows.Forms.ColumnHeader column_Gender;
        private System.Windows.Forms.ColumnHeader column_Hometown;
        private System.Windows.Forms.ColumnHeader column_City;
        private System.Windows.Forms.Button btnload_all;
        private System.Windows.Forms.Button btnshowformlog;
    }
}