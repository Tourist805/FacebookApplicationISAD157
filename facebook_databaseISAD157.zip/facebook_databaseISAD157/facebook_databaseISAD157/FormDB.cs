﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace facebook_databaseISAD157
{
    public partial class FormDB : Form
    {
        private User currentUser;
        public FormDB()
        {
            InitializeComponent();
            Database.Initialize_DataBase();
        }
        private void LoadData()
        {
            List<User> Allusers = User.getlistofUsers();
            lstviewUsers.Items.Clear();
            foreach(User usernow  in Allusers)
            {
                ListViewItem currentitem = new ListViewItem(new String[] { usernow.User_ID.ToString(), usernow.First_name, usernow.Last_name, usernow.Gender, usernow.Hometown, usernow.City });
                currentitem.Tag = usernow;
                lstviewUsers.Items.Add(currentitem);
            }
        }
       
        private void FormDB_Load(object sender, EventArgs e)
        {

        }

        private void btnload_all_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void lstviewUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstviewUsers.SelectedItems.Count > 0)
            {
                ListViewItem currentitem = lstviewUsers.SelectedItems[0];
                currentUser = (User)currentitem.Tag;

                String current_User_id = currentUser.User_ID.ToString();
                String current_First_name = currentUser.First_name;
                String current_Last_name = currentUser.Last_name;
                String current_gender = currentUser.Gender;
                String current_hometown = currentUser.Hometown;
                String current_city = currentUser.City;

                txtuser_id.Text = current_User_id;
                txtfirst_name.Text = current_First_name;
                txtlast_name.Text = current_Last_name;
                txtgender.Text = current_gender;
                txthometown.Text = current_hometown;
                txtcity.Text = current_city;
            }
            
        }

        private void btninsertrow_Click(object sender, EventArgs e)
        {
            String uid = txtuser_id.Text;
            String firstname = txtfirst_name.Text;
            String lastname = txtlast_name.Text;
            String gender = txtgender.Text;
            String hometown = txthometown.Text;
            String city = txtcity.Text;
            
            if( String.IsNullOrEmpty(firstname) || String.IsNullOrEmpty(gender) || String.IsNullOrEmpty(hometown) || String.IsNullOrEmpty(city))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            currentUser = User.InsertUser( firstname, lastname, gender, hometown, city);

            LoadData();
        }

        private void btnupdaterow_Click(object sender, EventArgs e)
        {
            String uid = txtuser_id.Text;
            String firstname = txtfirst_name.Text;
            String lastname = txtlast_name.Text;
            String gender = txtgender.Text;
            String hometown = txthometown.Text;
            String city = txtcity.Text;

            if (String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(firstname) || String.IsNullOrEmpty(gender) || String.IsNullOrEmpty(hometown) || String.IsNullOrEmpty(city))
            {
                MessageBox.Show("The item is empty");
                return;
            }

            currentUser.UpdateUSER(firstname, lastname, gender, hometown, city);

            LoadData();
        }

        private void btndeleterow_Click(object sender, EventArgs e)
        {
            if( currentUser == null)
            {
                MessageBox.Show("You have not selected a user to delete");
                return;
                
            }
            currentUser.DeleteUser();

            LoadData();
        }

        private void btnshowformlog_Click(object sender, EventArgs e)
        {
            Formentry formentry = new Formentry();
            this.Hide();
            formentry.Show();
        }
    }
}
