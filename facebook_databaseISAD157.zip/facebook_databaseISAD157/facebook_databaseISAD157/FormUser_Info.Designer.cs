﻿namespace facebook_databaseISAD157
{
    partial class FormUser_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpUser_profile = new System.Windows.Forms.GroupBox();
            this.btnupdateuserprofile = new System.Windows.Forms.Button();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txthametown = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.txtuser_id = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.txtuniversity_name = new System.Windows.Forms.TextBox();
            this.txtworkplacename = new System.Windows.Forms.TextBox();
            this.lstworkplaces = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.grpfriends = new System.Windows.Forms.GroupBox();
            this.btndeletefriendship = new System.Windows.Forms.Button();
            this.txtfrienduser_id = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lstviewfriends = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grpmessages = new System.Windows.Forms.GroupBox();
            this.btndeletemessage = new System.Windows.Forms.Button();
            this.txtreceiverid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtdatetime = new System.Windows.Forms.TextBox();
            this.btnmainmenu = new System.Windows.Forms.Button();
            this.lstviewmessages = new System.Windows.Forms.ListView();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btninsertuniversity = new System.Windows.Forms.Button();
            this.btninsertworkplace = new System.Windows.Forms.Button();
            this.btndeleteuniversity = new System.Windows.Forms.Button();
            this.btndeleteworkplace = new System.Windows.Forms.Button();
            this.lstuinversities = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.grpUser_profile.SuspendLayout();
            this.grpfriends.SuspendLayout();
            this.grpmessages.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpUser_profile
            // 
            this.grpUser_profile.Controls.Add(this.btnupdateuserprofile);
            this.grpUser_profile.Controls.Add(this.txtgender);
            this.grpUser_profile.Controls.Add(this.label7);
            this.grpUser_profile.Controls.Add(this.txtcity);
            this.grpUser_profile.Controls.Add(this.txthametown);
            this.grpUser_profile.Controls.Add(this.txtlastname);
            this.grpUser_profile.Controls.Add(this.txtfirstname);
            this.grpUser_profile.Controls.Add(this.txtuser_id);
            this.grpUser_profile.Controls.Add(this.label4);
            this.grpUser_profile.Controls.Add(this.label3);
            this.grpUser_profile.Controls.Add(this.label2);
            this.grpUser_profile.Controls.Add(this.label1);
            this.grpUser_profile.Controls.Add(this.lblUserID);
            this.grpUser_profile.Location = new System.Drawing.Point(12, 12);
            this.grpUser_profile.Name = "grpUser_profile";
            this.grpUser_profile.Size = new System.Drawing.Size(638, 227);
            this.grpUser_profile.TabIndex = 0;
            this.grpUser_profile.TabStop = false;
            this.grpUser_profile.Text = "Facebook User Profile";
            // 
            // btnupdateuserprofile
            // 
            this.btnupdateuserprofile.Location = new System.Drawing.Point(361, 169);
            this.btnupdateuserprofile.Name = "btnupdateuserprofile";
            this.btnupdateuserprofile.Size = new System.Drawing.Size(75, 23);
            this.btnupdateuserprofile.TabIndex = 18;
            this.btnupdateuserprofile.Text = "Update";
            this.btnupdateuserprofile.UseVisualStyleBackColor = true;
            this.btnupdateuserprofile.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(418, 46);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(100, 22);
            this.txtgender.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(358, 46);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "gender";
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(154, 175);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(165, 22);
            this.txtcity.TabIndex = 11;
            // 
            // txthametown
            // 
            this.txthametown.Location = new System.Drawing.Point(154, 142);
            this.txthametown.Name = "txthametown";
            this.txthametown.Size = new System.Drawing.Size(165, 22);
            this.txthametown.TabIndex = 10;
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(154, 105);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(165, 22);
            this.txtlastname.TabIndex = 9;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(153, 72);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(165, 22);
            this.txtfirstname.TabIndex = 8;
            // 
            // txtuser_id
            // 
            this.txtuser_id.Location = new System.Drawing.Point(154, 42);
            this.txtuser_id.Name = "txtuser_id";
            this.txtuser_id.Size = new System.Drawing.Size(53, 22);
            this.txtuser_id.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Current Town or City:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Hometown:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(69, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "First name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Location = new System.Drawing.Point(84, 42);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(63, 17);
            this.lblUserID.TabIndex = 0;
            this.lblUserID.Text = "User ID: ";
            // 
            // txtuniversity_name
            // 
            this.txtuniversity_name.Location = new System.Drawing.Point(412, 125);
            this.txtuniversity_name.Name = "txtuniversity_name";
            this.txtuniversity_name.Size = new System.Drawing.Size(206, 22);
            this.txtuniversity_name.TabIndex = 17;
            // 
            // txtworkplacename
            // 
            this.txtworkplacename.Location = new System.Drawing.Point(409, 21);
            this.txtworkplacename.Name = "txtworkplacename";
            this.txtworkplacename.Size = new System.Drawing.Size(206, 22);
            this.txtworkplacename.TabIndex = 16;
            // 
            // lstworkplaces
            // 
            this.lstworkplaces.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lstworkplaces.HideSelection = false;
            this.lstworkplaces.Location = new System.Drawing.Point(135, 21);
            this.lstworkplaces.Name = "lstworkplaces";
            this.lstworkplaces.Size = new System.Drawing.Size(255, 100);
            this.lstworkplaces.TabIndex = 12;
            this.lstworkplaces.UseCompatibleStateImageBehavior = false;
            this.lstworkplaces.View = System.Windows.Forms.View.Details;
            this.lstworkplaces.SelectedIndexChanged += new System.EventHandler(this.lstworkplaces_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Workplace name";
            this.columnHeader1.Width = 250;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(-111, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Universities:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(-95, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Workplace:";
            // 
            // grpfriends
            // 
            this.grpfriends.Controls.Add(this.btndeletefriendship);
            this.grpfriends.Controls.Add(this.txtfrienduser_id);
            this.grpfriends.Controls.Add(this.label8);
            this.grpfriends.Controls.Add(this.lstviewfriends);
            this.grpfriends.Location = new System.Drawing.Point(666, 12);
            this.grpfriends.Name = "grpfriends";
            this.grpfriends.Size = new System.Drawing.Size(430, 430);
            this.grpfriends.TabIndex = 1;
            this.grpfriends.TabStop = false;
            this.grpfriends.Text = "Friends";
            // 
            // btndeletefriendship
            // 
            this.btndeletefriendship.Location = new System.Drawing.Point(29, 380);
            this.btndeletefriendship.Name = "btndeletefriendship";
            this.btndeletefriendship.Size = new System.Drawing.Size(240, 23);
            this.btndeletefriendship.TabIndex = 5;
            this.btndeletefriendship.Text = "Delete a friend from a friends list";
            this.btndeletefriendship.UseVisualStyleBackColor = true;
            this.btndeletefriendship.Click += new System.EventHandler(this.btndeletefriendship_Click);
            // 
            // txtfrienduser_id
            // 
            this.txtfrienduser_id.Location = new System.Drawing.Point(149, 268);
            this.txtfrienduser_id.Name = "txtfrienduser_id";
            this.txtfrienduser_id.Size = new System.Drawing.Size(184, 22);
            this.txtfrienduser_id.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(29, 268);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Friend\'s User_ID";
            // 
            // lstviewfriends
            // 
            this.lstviewfriends.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5});
            this.lstviewfriends.HideSelection = false;
            this.lstviewfriends.Location = new System.Drawing.Point(29, 67);
            this.lstviewfriends.Name = "lstviewfriends";
            this.lstviewfriends.Size = new System.Drawing.Size(304, 160);
            this.lstviewfriends.TabIndex = 0;
            this.lstviewfriends.UseCompatibleStateImageBehavior = false;
            this.lstviewfriends.View = System.Windows.Forms.View.Details;
            this.lstviewfriends.SelectedIndexChanged += new System.EventHandler(this.lstviewfriends_SelectedIndexChanged);
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "User ID:";
            this.columnHeader3.Width = 100;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "First Name";
            this.columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Last Name";
            this.columnHeader5.Width = 100;
            // 
            // grpmessages
            // 
            this.grpmessages.Controls.Add(this.btndeletemessage);
            this.grpmessages.Controls.Add(this.txtreceiverid);
            this.grpmessages.Controls.Add(this.label10);
            this.grpmessages.Controls.Add(this.label9);
            this.grpmessages.Controls.Add(this.txtdatetime);
            this.grpmessages.Controls.Add(this.btnmainmenu);
            this.grpmessages.Controls.Add(this.lstviewmessages);
            this.grpmessages.Location = new System.Drawing.Point(12, 480);
            this.grpmessages.Name = "grpmessages";
            this.grpmessages.Size = new System.Drawing.Size(1084, 263);
            this.grpmessages.TabIndex = 2;
            this.grpmessages.TabStop = false;
            this.grpmessages.Text = "Messages";
            // 
            // btndeletemessage
            // 
            this.btndeletemessage.Location = new System.Drawing.Point(1003, 97);
            this.btndeletemessage.Name = "btndeletemessage";
            this.btndeletemessage.Size = new System.Drawing.Size(75, 23);
            this.btndeletemessage.TabIndex = 6;
            this.btndeletemessage.Text = "Delete";
            this.btndeletemessage.UseVisualStyleBackColor = true;
            this.btndeletemessage.Click += new System.EventHandler(this.btndeletemessage_Click);
            // 
            // txtreceiverid
            // 
            this.txtreceiverid.Location = new System.Drawing.Point(683, 19);
            this.txtreceiverid.Name = "txtreceiverid";
            this.txtreceiverid.Size = new System.Drawing.Size(100, 22);
            this.txtreceiverid.TabIndex = 5;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(618, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 17);
            this.label10.TabIndex = 4;
            this.label10.Text = "User_ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(785, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 17);
            this.label9.TabIndex = 3;
            this.label9.Text = "Date_time";
            // 
            // txtdatetime
            // 
            this.txtdatetime.Location = new System.Drawing.Point(863, 17);
            this.txtdatetime.Name = "txtdatetime";
            this.txtdatetime.Size = new System.Drawing.Size(207, 22);
            this.txtdatetime.TabIndex = 2;
            // 
            // btnmainmenu
            // 
            this.btnmainmenu.Location = new System.Drawing.Point(863, 212);
            this.btnmainmenu.Name = "btnmainmenu";
            this.btnmainmenu.Size = new System.Drawing.Size(202, 33);
            this.btnmainmenu.TabIndex = 1;
            this.btnmainmenu.Text = "Go back to the menu";
            this.btnmainmenu.UseVisualStyleBackColor = true;
            this.btnmainmenu.Click += new System.EventHandler(this.btnmainmenu_Click);
            // 
            // lstviewmessages
            // 
            this.lstviewmessages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.lstviewmessages.HideSelection = false;
            this.lstviewmessages.Location = new System.Drawing.Point(46, 57);
            this.lstviewmessages.Name = "lstviewmessages";
            this.lstviewmessages.Size = new System.Drawing.Size(811, 179);
            this.lstviewmessages.TabIndex = 0;
            this.lstviewmessages.UseCompatibleStateImageBehavior = false;
            this.lstviewmessages.View = System.Windows.Forms.View.Details;
            this.lstviewmessages.SelectedIndexChanged += new System.EventHandler(this.lstviewmessages_SelectedIndexChanged);
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "User ID";
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "First name";
            this.columnHeader7.Width = 100;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Last Name";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Date and Time";
            this.columnHeader9.Width = 140;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Text";
            this.columnHeader10.Width = 400;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btninsertuniversity);
            this.groupBox1.Controls.Add(this.btninsertworkplace);
            this.groupBox1.Controls.Add(this.btndeleteuniversity);
            this.groupBox1.Controls.Add(this.btndeleteworkplace);
            this.groupBox1.Controls.Add(this.lstuinversities);
            this.groupBox1.Controls.Add(this.lstworkplaces);
            this.groupBox1.Controls.Add(this.txtuniversity_name);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtworkplacename);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(21, 240);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(629, 246);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Additional information";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btninsertuniversity
            // 
            this.btninsertuniversity.Location = new System.Drawing.Point(543, 167);
            this.btninsertuniversity.Name = "btninsertuniversity";
            this.btninsertuniversity.Size = new System.Drawing.Size(75, 23);
            this.btninsertuniversity.TabIndex = 24;
            this.btninsertuniversity.Text = "Insert";
            this.btninsertuniversity.UseVisualStyleBackColor = true;
            this.btninsertuniversity.Click += new System.EventHandler(this.btninsertuniversity_Click);
            // 
            // btninsertworkplace
            // 
            this.btninsertworkplace.Location = new System.Drawing.Point(540, 71);
            this.btninsertworkplace.Name = "btninsertworkplace";
            this.btninsertworkplace.Size = new System.Drawing.Size(75, 23);
            this.btninsertworkplace.TabIndex = 23;
            this.btninsertworkplace.Text = "Insert";
            this.btninsertworkplace.UseVisualStyleBackColor = true;
            this.btninsertworkplace.Click += new System.EventHandler(this.btninsertworkplace_Click);
            // 
            // btndeleteuniversity
            // 
            this.btndeleteuniversity.Location = new System.Drawing.Point(412, 167);
            this.btndeleteuniversity.Name = "btndeleteuniversity";
            this.btndeleteuniversity.Size = new System.Drawing.Size(75, 23);
            this.btndeleteuniversity.TabIndex = 22;
            this.btndeleteuniversity.Text = "Delete";
            this.btndeleteuniversity.UseVisualStyleBackColor = true;
            this.btndeleteuniversity.Click += new System.EventHandler(this.btndeleteuniversity_Click);
            // 
            // btndeleteworkplace
            // 
            this.btndeleteworkplace.Location = new System.Drawing.Point(409, 71);
            this.btndeleteworkplace.Name = "btndeleteworkplace";
            this.btndeleteworkplace.Size = new System.Drawing.Size(75, 23);
            this.btndeleteworkplace.TabIndex = 21;
            this.btndeleteworkplace.Text = "Delete";
            this.btndeleteworkplace.UseVisualStyleBackColor = true;
            this.btndeleteworkplace.Click += new System.EventHandler(this.btndeleteworkplace_Click);
            // 
            // lstuinversities
            // 
            this.lstuinversities.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2});
            this.lstuinversities.HideSelection = false;
            this.lstuinversities.Location = new System.Drawing.Point(135, 140);
            this.lstuinversities.Name = "lstuinversities";
            this.lstuinversities.Size = new System.Drawing.Size(255, 100);
            this.lstuinversities.TabIndex = 18;
            this.lstuinversities.UseCompatibleStateImageBehavior = false;
            this.lstuinversities.View = System.Windows.Forms.View.Details;
            this.lstuinversities.SelectedIndexChanged += new System.EventHandler(this.lstuinversities_SelectedIndexChanged);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "University name";
            this.columnHeader2.Width = 250;
            // 
            // FormUser_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 755);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpmessages);
            this.Controls.Add(this.grpfriends);
            this.Controls.Add(this.grpUser_profile);
            this.Name = "FormUser_Info";
            this.Text = "FormUser_Info";
            this.Load += new System.EventHandler(this.FormUser_Info_Load);
            this.grpUser_profile.ResumeLayout(false);
            this.grpUser_profile.PerformLayout();
            this.grpfriends.ResumeLayout(false);
            this.grpfriends.PerformLayout();
            this.grpmessages.ResumeLayout(false);
            this.grpmessages.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpUser_profile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.ListView lstworkplaces;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txthametown;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.TextBox txtuser_id;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpfriends;
        private System.Windows.Forms.ListView lstviewfriends;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.GroupBox grpmessages;
        private System.Windows.Forms.ListView lstviewmessages;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtuniversity_name;
        private System.Windows.Forms.TextBox txtworkplacename;
        private System.Windows.Forms.Button btnupdateuserprofile;
        private System.Windows.Forms.Button btnmainmenu;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtfrienduser_id;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btndeletefriendship;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ListView lstuinversities;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btninsertuniversity;
        private System.Windows.Forms.Button btninsertworkplace;
        private System.Windows.Forms.Button btndeleteuniversity;
        private System.Windows.Forms.Button btndeleteworkplace;
        private System.Windows.Forms.TextBox txtdatetime;
        private System.Windows.Forms.Button btndeletemessage;
        private System.Windows.Forms.TextBox txtreceiverid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}