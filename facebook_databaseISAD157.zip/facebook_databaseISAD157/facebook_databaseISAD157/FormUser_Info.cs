﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace facebook_databaseISAD157
{
    public partial class FormUser_Info : Form
    {
        private User currentUser;
        private User.Friendship currentfriendship;
        private User user;
        private User.Message currentmessage;
        private User.University currentuniversity;
        private User.Workplace currentworkplace;

        public string uid
        {
            get { return txtuser_id.Text; }
            set { txtuser_id.Text = value; }
        }
        private string gender, hometown, city, first_name, last_name, frinedfirstname, friendlastname;
        public FormUser_Info()
        {
            InitializeComponent();
            Database.Initialize_DataBase();
        }
        public void LoadData()
        {
            //List<U
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        // LoadFriends method will put the data from user class to fill the listview for friends
        private void LoadFriends()
        {
            string uid = txtuser_id.Text;
            List<User.Friendship> Allfriends = User.getfriendships(uid);
            List<User> Allusers = User.getlistofUsers();
            lstviewfriends.Items.Clear();

            // we go through all friendships in list of friendships(Allfriends)
            foreach(User.Friendship friend in Allfriends) 
            {
                // find the records where sender_id equals our user_id from user profile
                if (friend.user_id1 == Convert.ToInt32(uid))
                   {
                    // then we define a user reformation with given user_id
                        foreach (User u in Allusers)
                            {
                                // this condition help us to find from receiver_id his personal information 
                                if(u.User_ID == friend.user_id2)
                                    {
                                        ListViewItem currentitem = new ListViewItem(new String[] { friend.user_id2.ToString(), u.First_name, u.Last_name });
                                        currentitem.Tag = friend;
                                        lstviewfriends.Items.Add(currentitem);
                                    }
                                
                            }
              
                   }
            }
        }
        // LoadMessages method will put the data from datatables message and facebook users to Messages list view
        public void LoadMessages()
        {
            string uid = txtuser_id.Text;
            int id = Convert.ToInt32(uid);
            List<User.Message> messages = User.getlistofmessages(uid);
            List<User> Allusers = User.getlistofUsers();
            lstviewmessages.Items.Clear();
            // go through all messages
            foreach(User.Message message in messages)
            {
                // if we found all messages from this user 
                if(message.User_ID1 == id)
                    // find the information about this user in data table facebook_users and add a record to the row
                    foreach (User u in Allusers)
                    {
                       if(u.User_ID == message.User_ID2)
                        {

                            ListViewItem currentitem = new ListViewItem(new String[] { u.User_ID.ToString(), u.First_name, u.Last_name, message.Date_time, message.Message_text });
                            currentitem.Tag = message;
                            lstviewmessages.Items.Add(currentitem);
                        }
                        
                    }
                
                    
                                
            }
        }
        // if we want to see list of universities 
        public void Loadlistofuniversities(string user_id)
        {
            List<User.University> alluniversities = User.getlistsofuniversities(user_id);
            lstuinversities.Items.Clear();
            // go through the table universitites SQL
            foreach (User.University universitynow in alluniversities)
            {
                ListViewItem item = new ListViewItem(new String[] { universitynow.university_name });
                item.Tag = universitynow;
                lstuinversities.Items.Add(item);

            }
        }
        public void Loadlistofworkplaces(string user_id)
        {
            List<User.Workplace> allworkplaces = User.getlistsofworkplaces(user_id);
            lstworkplaces.Items.Clear();
            foreach (User.Workplace workplacenow in allworkplaces)
            {
                ListViewItem item = new ListViewItem(new String[] { workplacenow.workplace_name });
                item.Tag = workplacenow;
                lstworkplaces.Items.Add(item);

            }
        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void lstuinversities_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstuinversities.SelectedItems.Count > 0)
            {
                ListViewItem item = lstuinversities.SelectedItems[0];
                currentuniversity = (User.University)item.Tag;

                String current_uniname = currentuniversity.university_name;
                txtuniversity_name.Text = current_uniname;
            }
        }

        private void lstworkplaces_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstworkplaces.SelectedItems.Count > 0)
            {
                ListViewItem item = lstworkplaces.SelectedItems[0];
                currentworkplace = (User.Workplace)item.Tag;

                String current_workname = currentworkplace.workplace_name;
                txtworkplacename.Text = current_workname;
            }
        }

        

        private void btninsertuniversity_Click(object sender, EventArgs e)
        {
            string uid = txtuser_id.Text;
            string uni = txtuniversity_name.Text;
            if (String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(uni))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            currentuniversity = User.InsertUniversity(uid, uni);
            Loadlistofworkplaces(uid);
        }

        private void btndeleteworkplace_Click(object sender, EventArgs e)
        {
            string uid = txtuser_id.Text;
            string work = txtworkplacename.Text;
            if (String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(work))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            DELETEworkplace(uid, work);
            //user.Deleteworkplace(uid, work);
            Loadlistofworkplaces(uid);
        }

        private void btndeleteuniversity_Click(object sender, EventArgs e)
        {
            string uid = txtuser_id.Text;
            string uni = txtuniversity_name.Text;
            if (String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(uni))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            DELETEuniversity(uid, uni);
            //user.DeleteUniversity(uid, uni);
            Loadlistofuniversities(uid);
        }

        private void lstviewmessages_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstviewmessages.SelectedItems.Count > 0)
            {
                ListViewItem item = lstviewmessages.SelectedItems[0];
                currentmessage = (User.Message)item.Tag;

                String current_message = currentmessage.Date_time;
                String current_recid = currentmessage.User_ID2.ToString();
                txtdatetime.Text = current_message;
                txtreceiverid.Text = current_recid;
                
            }
        }

        private void txtfilterfirstname_TextChanged(object sender, EventArgs e)
        {
           
          
        }

        private void btndeletemessage_Click(object sender, EventArgs e)
        {
            String uid = txtuser_id.Text;
            String uid2 = txtreceiverid.Text;
            String date_time = txtdatetime.Text;
            if (String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(uid2) || String.IsNullOrEmpty(date_time))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            DELETEmessage(uid, uid2, date_time);
            LoadMessages();
        }

        private void btninsertworkplace_Click(object sender, EventArgs e)
        {
            string uid = txtuser_id.Text;
            string uni = txtuniversity_name.Text;
            if(String.IsNullOrEmpty(uid) || String.IsNullOrEmpty(uni))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            currentworkplace = User.InsertWork(uid, uni);
            Loadlistofworkplaces(uid);
        }

        private void lstviewfriends_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lstviewfriends.SelectedItems.Count > 0)
            {
                ListViewItem item = lstviewfriends.SelectedItems[0];
                currentfriendship = (User.Friendship)item.Tag;

                String current_userid = currentfriendship.user_id2.ToString();
                

                txtfrienduser_id.Text = current_userid;
                
            }
        }

        private void btndeletefriendship_Click(object sender, EventArgs e)
        {
            String user_id = txtfrienduser_id.Text;
            String uid = txtuser_id.Text;
            if (String.IsNullOrEmpty(user_id))
            {
                MessageBox.Show("Pick a friend, in order to delete a friend");
            }
            //user.Deletefriendship(user_id, uid);
            DELETEFRIENDSHIP(user_id, uid);
            LoadFriends();
        }

        private void FormUser_Info_Load(object sender, EventArgs e)
        {

            Formentry formentry = new Formentry();
            string id = txtuser_id.Text;
            string query = "SELECT * FROM facebook_users WHERE user_id=" + id;

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            MySqlDataReader dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                first_name = dataReader["first_name"].ToString();
                last_name = dataReader["last_name"].ToString();
                gender = dataReader["gender"].ToString();
                hometown = dataReader["hometown"].ToString();
                city = dataReader["city"].ToString();
            }

            txtfirstname.Text = first_name;
            txtlastname.Text = last_name;
            txtgender.Text = gender;
            txthametown.Text = hometown;
            txtcity.Text = city;
            dataReader.Close();
            Database.connection_DB.Close();
            
            LoadFriends();
            LoadMessages();
            Loadlistofuniversities(id);
            Loadlistofworkplaces(id);
        }
       
        private void btnupdate_Click(object sender, EventArgs e)
        {
            string uid = txtuser_id.Text;
            string firstname = txtfirstname.Text;
            string lastname = txtlastname.Text;
            string gender = txtgender.Text;
            string hometown = txthametown.Text;
            string city = txtcity.Text;

            if (String.IsNullOrEmpty(lastname) || String.IsNullOrEmpty(firstname) || String.IsNullOrEmpty(gender) || String.IsNullOrEmpty(hometown) || String.IsNullOrEmpty(city))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            UpdateUserinfo(uid, firstname, lastname, gender, hometown, city);
            //currentUser.UpdateUSER(firstname, lastname, gender, hometown, city);
            MessageBox.Show("You have succesfully updated your personal information");

        }
        private void UpdateUserinfo(string uid,string First_name, string Last_name, string Gender, string Hometown, string City)
        {
            int id = Convert.ToInt32(uid);
            String query = String.Format("UPDATE facebook_users SET first_name='{0}', last_name='{1}', gender='{2}', hometown='{3}', city='{4}' WHERE user_id='{5}'", First_name, Last_name, Gender, Hometown, City, id);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        private void DELETEmessage(string uid, string uid2, string date_time)
        {
            int id1 = Convert.ToInt32(uid);
            int id2 = Convert.ToInt32(uid2);
            String query = String.Format("DELETE FROM messages WHERE user_id1='{0}' AND user_id2='{1}'", id1, id2);
            MySqlCommand cmd = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            cmd.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        private void DELETEuniversity(string uid, string university_name)
        {
            int id = Convert.ToInt32(uid);
            String query = String.Format("DELETE FROM universities WHERE user_id='{0}' AND university_name='{1}' ", id, university_name);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        private void DELETEworkplace(string uid, string work)
        {
            int id = Convert.ToInt32(uid);
            String query = String.Format("DELETE FROM workplaces WHERE user_id='{0}' AND workplace_name='{1}' ", id, work);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        private void DELETEFRIENDSHIP(string uid1, string uid2)
        {
            int id1 = Convert.ToInt32(uid1);
            int id2 = Convert.ToInt32(uid2);
            String query = String.Format("DELETE FROM facebook_friendships WHERE user_id1='{0}' AND user_id2='{1}' ", uid1, uid2);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        private void btnmainmenu_Click(object sender, EventArgs e)
        {
            Formentry formentry = new Formentry();
            formentry.Show();
            this.Hide();
        }
    }
}
