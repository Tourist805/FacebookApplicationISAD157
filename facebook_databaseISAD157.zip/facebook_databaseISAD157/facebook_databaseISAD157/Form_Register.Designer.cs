﻿namespace facebook_databaseISAD157
{
    partial class Form_Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtgender = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnregister = new System.Windows.Forms.Button();
            this.btntomainmenu = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txthometown = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtcity);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txthometown);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btntomainmenu);
            this.groupBox1.Controls.Add(this.btnregister);
            this.groupBox1.Controls.Add(this.txtgender);
            this.groupBox1.Controls.Add(this.txtlastname);
            this.groupBox1.Controls.Add(this.txtfirstname);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(492, 327);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User information";
            // 
            // txtgender
            // 
            this.txtgender.Location = new System.Drawing.Point(131, 96);
            this.txtgender.Name = "txtgender";
            this.txtgender.Size = new System.Drawing.Size(168, 22);
            this.txtgender.TabIndex = 5;
            // 
            // txtlastname
            // 
            this.txtlastname.Location = new System.Drawing.Point(130, 68);
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(168, 22);
            this.txtlastname.TabIndex = 4;
            // 
            // txtfirstname
            // 
            this.txtfirstname.Location = new System.Drawing.Point(130, 36);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(168, 22);
            this.txtfirstname.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(64, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Gender:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Last Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name:";
            // 
            // btnregister
            // 
            this.btnregister.Location = new System.Drawing.Point(41, 282);
            this.btnregister.Name = "btnregister";
            this.btnregister.Size = new System.Drawing.Size(92, 33);
            this.btnregister.TabIndex = 10;
            this.btnregister.Text = "Register";
            this.btnregister.UseVisualStyleBackColor = true;
            this.btnregister.Click += new System.EventHandler(this.btnregister_Click);
            // 
            // btntomainmenu
            // 
            this.btntomainmenu.Location = new System.Drawing.Point(300, 282);
            this.btntomainmenu.Name = "btntomainmenu";
            this.btntomainmenu.Size = new System.Drawing.Size(186, 33);
            this.btntomainmenu.TabIndex = 11;
            this.btntomainmenu.Text = "Go back to the menu";
            this.btntomainmenu.UseVisualStyleBackColor = true;
            this.btntomainmenu.Click += new System.EventHandler(this.btntomainmenu_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Hometown:";
            // 
            // txthometown
            // 
            this.txthometown.Location = new System.Drawing.Point(131, 131);
            this.txthometown.Name = "txthometown";
            this.txthometown.Size = new System.Drawing.Size(332, 22);
            this.txthometown.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(80, 162);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "City:";
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(131, 160);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(332, 22);
            this.txtcity.TabIndex = 15;
            // 
            // Form_Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 365);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form_Register";
            this.Text = "Form_Register";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtgender;
        private System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btntomainmenu;
        private System.Windows.Forms.Button btnregister;
        private System.Windows.Forms.TextBox txthometown;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.Label label7;
    }
}