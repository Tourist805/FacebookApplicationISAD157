﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace facebook_databaseISAD157
{
    public partial class Form_Register : Form
    {
        private User currentUser;
        private User.Workplace currentWorkplace;
        private User.University currentUniversity;
        private int id = 5001;
        public Form_Register()
        {
            InitializeComponent();
            Database.Initialize_DataBase();
        }

        private void btntomainmenu_Click(object sender, EventArgs e)
        {
            Formentry formentry = new Formentry();
            formentry.Show();
            this.Hide();
            
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            string first_name = txtfirstname.Text;
            string last_name = txtlastname.Text;
            string gender = txtgender.Text;
            string hometown = txthometown.Text;
            string city = txtcity.Text;
            if (String.IsNullOrEmpty(first_name) || String.IsNullOrEmpty(last_name) || String.IsNullOrEmpty(gender) || String.IsNullOrEmpty(hometown) || String.IsNullOrEmpty(city))
            {
                MessageBox.Show("The item is empty");
                return;
            }
            
            currentUser = User.InsertUser(first_name, last_name, gender, hometown, city);
            string str = "Welcome " + first_name + ' ' + last_name + "your user_id is " + id.ToString();
            MessageBox.Show(str);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
