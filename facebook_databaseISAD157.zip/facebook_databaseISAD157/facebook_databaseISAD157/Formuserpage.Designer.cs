﻿namespace facebook_databaseISAD157
{
    partial class Formuserpage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.labelcity = new System.Windows.Forms.Label();
            this.labelHometown = new System.Windows.Forms.Label();
            this.labelgender = new System.Windows.Forms.Label();
            this.labeluserlastname = new System.Windows.Forms.Label();
            this.labelusername = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstworkplaces = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btngpbacktomainmenu = new System.Windows.Forms.Button();
            this.btngotouserinfopage = new System.Windows.Forms.Button();
            this.labeluser_id = new System.Windows.Forms.Label();
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lstuniversity = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelcity);
            this.groupBox1.Controls.Add(this.labelHometown);
            this.groupBox1.Controls.Add(this.labelgender);
            this.groupBox1.Controls.Add(this.labeluserlastname);
            this.groupBox1.Controls.Add(this.labelusername);
            this.groupBox1.Location = new System.Drawing.Point(54, 36);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(253, 207);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User profile";
            // 
            // labelcity
            // 
            this.labelcity.AutoSize = true;
            this.labelcity.Location = new System.Drawing.Point(39, 145);
            this.labelcity.Name = "labelcity";
            this.labelcity.Size = new System.Drawing.Size(31, 17);
            this.labelcity.TabIndex = 4;
            this.labelcity.Text = "City";
            // 
            // labelHometown
            // 
            this.labelHometown.AutoSize = true;
            this.labelHometown.Location = new System.Drawing.Point(36, 124);
            this.labelHometown.Name = "labelHometown";
            this.labelHometown.Size = new System.Drawing.Size(74, 17);
            this.labelHometown.TabIndex = 3;
            this.labelHometown.Text = "Hometown";
            // 
            // labelgender
            // 
            this.labelgender.AutoSize = true;
            this.labelgender.Location = new System.Drawing.Point(36, 103);
            this.labelgender.Name = "labelgender";
            this.labelgender.Size = new System.Drawing.Size(56, 17);
            this.labelgender.TabIndex = 2;
            this.labelgender.Text = "Gender";
            // 
            // labeluserlastname
            // 
            this.labeluserlastname.AutoSize = true;
            this.labeluserlastname.Location = new System.Drawing.Point(33, 82);
            this.labeluserlastname.Name = "labeluserlastname";
            this.labeluserlastname.Size = new System.Drawing.Size(103, 17);
            this.labeluserlastname.TabIndex = 1;
            this.labeluserlastname.Text = "User last name";
            // 
            // labelusername
            // 
            this.labelusername.AutoSize = true;
            this.labelusername.Location = new System.Drawing.Point(33, 51);
            this.labelusername.Name = "labelusername";
            this.labelusername.Size = new System.Drawing.Size(77, 17);
            this.labelusername.TabIndex = 0;
            this.labelusername.Text = "User name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lstuniversity);
            this.groupBox2.Controls.Add(this.lstworkplaces);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(54, 249);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(421, 267);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Additional Information";
            // 
            // lstworkplaces
            // 
            this.lstworkplaces.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.lstworkplaces.HideSelection = false;
            this.lstworkplaces.Location = new System.Drawing.Point(114, 152);
            this.lstworkplaces.Name = "lstworkplaces";
            this.lstworkplaces.Size = new System.Drawing.Size(211, 97);
            this.lstworkplaces.TabIndex = 3;
            this.lstworkplaces.UseCompatibleStateImageBehavior = false;
            this.lstworkplaces.View = System.Windows.Forms.View.Details;
            this.lstworkplaces.SelectedIndexChanged += new System.EventHandler(this.lstworkplaces_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Workplace ";
            this.columnHeader1.Width = 200;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Workplaces";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Universities";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.listView3);
            this.groupBox3.Location = new System.Drawing.Point(481, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 358);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Friends";
            // 
            // listView3
            // 
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader6});
            this.listView3.HideSelection = false;
            this.listView3.Location = new System.Drawing.Point(6, 36);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(376, 286);
            this.listView3.TabIndex = 0;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            this.listView3.SelectedIndexChanged += new System.EventHandler(this.listView3_SelectedIndexChanged);
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "User ID";
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "First name";
            this.columnHeader3.Width = 120;
            // 
            // btngpbacktomainmenu
            // 
            this.btngpbacktomainmenu.Location = new System.Drawing.Point(523, 586);
            this.btngpbacktomainmenu.Name = "btngpbacktomainmenu";
            this.btngpbacktomainmenu.Size = new System.Drawing.Size(207, 23);
            this.btngpbacktomainmenu.TabIndex = 3;
            this.btngpbacktomainmenu.Text = "Go back to the main menu";
            this.btngpbacktomainmenu.UseVisualStyleBackColor = true;
            this.btngpbacktomainmenu.Click += new System.EventHandler(this.btngpbacktomainmenu_Click);
            // 
            // btngotouserinfopage
            // 
            this.btngotouserinfopage.Location = new System.Drawing.Point(829, 586);
            this.btngotouserinfopage.Name = "btngotouserinfopage";
            this.btngotouserinfopage.Size = new System.Drawing.Size(150, 23);
            this.btngotouserinfopage.TabIndex = 4;
            this.btngotouserinfopage.Text = "Change Information";
            this.btngotouserinfopage.UseVisualStyleBackColor = true;
            this.btngotouserinfopage.Click += new System.EventHandler(this.btngotouserinfopage_Click);
            // 
            // labeluser_id
            // 
            this.labeluser_id.AutoSize = true;
            this.labeluser_id.Location = new System.Drawing.Point(315, 13);
            this.labeluser_id.Name = "labeluser_id";
            this.labeluser_id.Size = new System.Drawing.Size(57, 17);
            this.labeluser_id.TabIndex = 5;
            this.labeluser_id.Text = "User_id";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Last name";
            this.columnHeader6.Width = 120;
            // 
            // lstuniversity
            // 
            this.lstuniversity.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4});
            this.lstuniversity.HideSelection = false;
            this.lstuniversity.Location = new System.Drawing.Point(114, 36);
            this.lstuniversity.Name = "lstuniversity";
            this.lstuniversity.Size = new System.Drawing.Size(211, 97);
            this.lstuniversity.TabIndex = 4;
            this.lstuniversity.UseCompatibleStateImageBehavior = false;
            this.lstuniversity.View = System.Windows.Forms.View.Details;
            this.lstuniversity.SelectedIndexChanged += new System.EventHandler(this.lstuniversity_SelectedIndexChanged);
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "University";
            this.columnHeader4.Width = 200;
            // 
            // Formuserpage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 662);
            this.Controls.Add(this.labeluser_id);
            this.Controls.Add(this.btngotouserinfopage);
            this.Controls.Add(this.btngpbacktomainmenu);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Formuserpage";
            this.Text = "Formuserpage";
            this.Load += new System.EventHandler(this.Formuserpage_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labelcity;
        private System.Windows.Forms.Label labelHometown;
        private System.Windows.Forms.Label labelgender;
        private System.Windows.Forms.Label labeluserlastname;
        private System.Windows.Forms.Label labelusername;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView lstworkplaces;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Button btngpbacktomainmenu;
        private System.Windows.Forms.Button btngotouserinfopage;
        private System.Windows.Forms.Label labeluser_id;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ListView lstuniversity;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}