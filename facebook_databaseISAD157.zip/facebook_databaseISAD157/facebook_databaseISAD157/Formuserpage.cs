﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace facebook_databaseISAD157
{
    public partial class Formuserpage : Form
    {
        private User.Workplace currentworkplace;
        private User.University currentuniversity;
        private User.Friendship currentfriendship;
        public string user_idname
        {
            get { return labelusername.Text; }
            set { labelusername.Text = value; }
        }
        public string user_id 
        {
            get { return labeluser_id.Text; }
            set { labeluser_id.Text = value; }
        }
        public string user_idlastname
        {
            get { return labeluserlastname.Text;  }
            set { labeluserlastname.Text = value; }
        }
        public string first_name, last_name, gender, hometown, city;
        public Formuserpage()
        {
            InitializeComponent();
            Database.Initialize_DataBase();
        }
        public void Loadlistofuniversities(string user_id)
        {
            List<User.University> alluniversities = User.getlistsofuniversities(user_id);
            lstuniversity.Items.Clear();
            foreach (User.University universitynow in alluniversities)
            {
                ListViewItem item = new ListViewItem(new String[] { universitynow.university_name });
                item.Tag = universitynow;
                lstuniversity.Items.Add(item);

            }
        }
        public void Loadlistofworkplaces(string user_id)
        {
            List<User.Workplace> allworkplaces = User.getlistsofworkplaces(user_id);
            lstworkplaces.Items.Clear();
            foreach(User.Workplace workplacenow in allworkplaces)
            {
                ListViewItem item = new ListViewItem(new String[] { workplacenow.workplace_name });
                item.Tag = workplacenow;
                lstworkplaces.Items.Add(item);
                
            }
        }
        private void LoadFriends()
        {
            string uid = labeluser_id.Text;
            List<User.Friendship> Allfriends = User.getfriendships(uid);
            List<User> Allusers = User.getlistofUsers();
            listView3.Items.Clear();
            foreach (User.Friendship friend in Allfriends)
            {
                if (friend.user_id1 == Convert.ToInt32(uid))
                {
                    foreach (User u in Allusers)
                    {
                        if (u.User_ID == friend.user_id2)
                        {
                            ListViewItem currentitem = new ListViewItem(new String[] { friend.user_id2.ToString(), u.First_name, u.Last_name });
                            currentitem.Tag = friend;
                            listView3.Items.Add(currentitem);
                        }

                    }

                }
            }
        }
        

        private void lstworkplaces_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstworkplaces.SelectedItems.Count > 0)
            {
                ListViewItem viewItem = lstworkplaces.SelectedItems[0];
                currentworkplace = (User.Workplace)viewItem.Tag;
            }
        }

        private void lstuniversity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstuniversity.SelectedItems.Count > 0)
            {
                ListViewItem item = lstuniversity.SelectedItems[0];
                currentuniversity = (User.University)item.Tag;
            }
        }

        private void listView3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView3.SelectedItems.Count > 0)
            {
                ListViewItem cur_item = listView3.SelectedItems[0];
                currentfriendship = (User.Friendship)cur_item.Tag;
            }
        }

      
       // public void loadfriendships(string )
        private void btngpbacktomainmenu_Click(object sender, EventArgs e)
        {
            Formentry formentry = new Formentry();
            formentry.Show();
            this.Hide();
        }

        private void btngotouserinfopage_Click(object sender, EventArgs e)
        {
            FormUser_Info formuser = new FormUser_Info();
            formuser.uid = this.labeluser_id.Text;
            formuser.Show();
            this.Hide();
        }

        private void Formuserpage_Load(object sender, EventArgs e)
        {
            Formentry formentry = new Formentry();
            string id = labeluser_id.Text;
            string query = "SELECT first_name, last_name, gender, hometown, city FROM facebook_users WHERE user_id=" + id;

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            MySqlDataReader dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                gender = dataReader["gender"].ToString();
                hometown = dataReader["hometown"].ToString();
                city = dataReader["city"].ToString();
            }
            labelHometown.Text = hometown;
            labelcity.Text = city;
            labelgender.Text = gender;
            dataReader.Close();
            Database.connection_DB.Close();
            Loadlistofuniversities(id);
            Loadlistofworkplaces(id);
            LoadFriends();
           


        }
    }
}
