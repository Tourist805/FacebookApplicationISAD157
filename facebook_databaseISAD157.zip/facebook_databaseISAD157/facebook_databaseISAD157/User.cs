﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace facebook_databaseISAD157
{

    // Create a class user which will contain user information such as his id, first name, last name, gender, hometown and city
    class User
    {
        //our variables with getters and setters
        public int User_ID { get; private set; }
        public string First_name { get; private set; }
        public string Last_name { get; private set; }
        public string Gender { get; private set; }
        public string Hometown { get; private set; }
        public string City { get; private set; }
        public virtual ICollection<Workplace> Workplaces { get; private set; }
        public virtual ICollection<University> Universities { get; private set; }
        public virtual ICollection<Friendship> Friendships { get; private set; }
        public virtual ICollection<Message> Messages { get; private set; }

        //create our class User with the varibles
        public User(int ID, string first_name, string last_name, string gender, string hometown, string city)
        {
            User_ID = ID;
            First_name = first_name;
            Last_name = last_name;
            Gender = gender;
            Hometown = hometown;
            City = city;
        }
        //  create university class with user_id and university name attributes and add a constaint
        public class University
        {
            public int theid { get; private set; }
            public string university_name { get; private set; }
            public University(int uid, string UniversityN)
            {
                theid = uid;
                university_name = UniversityN;
            }
        }
        // create workplace class with user_id and workplace name attributes and add a constraint
        public class Workplace
        {
            public int theid { get; private set; }
            public string workplace_name { get; private set; }
            public Workplace(int uid, string WOrkplace)
            {
                theid = uid;
                workplace_name = WOrkplace;
            }
        }
        // create friendship class with user_id1 and user_id2 means sender_id and receiver_id respectively attributes and add a constraint
        public class Friendship
        {
            public int user_id1 { get; private set; }
            public int user_id2 { get; private set; }

            public Friendship(int User_id1, int User_id2)
            {
                user_id1 = User_id1;
                user_id2 = User_id2;
            }
            
        }
        // create friendship class with user_id1 and user_id2 means sender_id,  and receiver_id respectively,date_time, message text attributes and add a constraint
        public class Message
        {
            public int User_ID1 { get; private set; }
            public int User_ID2 { get; private set; }
            public string Date_time { get; private set; }
            public string Message_text { get; private set; }
            public Message()
            {

            }
            public Message(int id1, int id2, string date, string message)
            {
                User_ID1 = id1;
                User_ID2 = id2;
                Date_time = date;
                Message_text = message;
            }
        }
      
        public User()
        {
            Workplaces = new List<Workplace>();
            Universities = new List<University>();
            Friendships = new List<Friendship>();
        }
        // method below will request the database to retrive data from facebook_frienship table
        // and put to the friendship class and then add to the list of the friendships, this function
        // will return a list of friendships
        public static List<Friendship> getfriendships(string uid1)
        {
            int id1 = Convert.ToInt32(uid1);
            List<Friendship> friendships = new List<Friendship>();
            // Select syntax:
            // SELECT column_name1, columname2
            // FROM table1name
            // INNER JOIN tablename2
            // ON condtion1
            // Where condition
            String query = "SELECT  facebook_users.user_id, facebook_users.first_name, facebook_users.last_name FROM facebook_friendships INNER JOIN facebook_users ON facebook_friendships.user_id2 = facebook_users.user_id WHERE facebook_friendships.user_id1 =" + uid1;
            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();
            // create a reader to read the data from the table we got from query
            MySqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                int id2 = (int)reader["user_id"];
                string id2first_name = reader["first_name"].ToString();
                string id2last_name = reader["last_name"].ToString();
                // create friendship with our data
                Friendship newfriendship = new Friendship(id1, id2);
                // add newfriendhip to the list of friendships
                friendships.Add(newfriendship);
            }

            reader.Close();
            Database.connection_DB.Close();
            return friendships;
        }
        public void insertfriendship(string uid1, string uid2)
        {
            int id1 = Convert.ToInt32(uid1);
            int id2 = Convert.ToInt32(uid2);
            string query = String.Format("INSERT INTO facebook_friendships (user_id1, user_id2) VALUES ('{0}', '{1}')", id1, id2);
            MySqlCommand cmd = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            cmd.ExecuteNonQuery();

            Friendship newfriendship = new Friendship(id1, id2);

            Database.connection_DB.Close();
        }
        public void Deletefriendship(string uid1, string uid2)
        {
            int id1 = Convert.ToInt32(uid1);
            int id2 = Convert.ToInt32(uid2);
            String query = String.Format("DELETE FROM facebook_friendships WHERE user_id1='{0}', user_id2='{1}' ", uid1, uid2);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        public static List<User.Workplace> getlistsofworkplaces(String user_id)
        {
            int id = Convert.ToInt32(user_id);
            List<User.Workplace> Workplaces = new List<User.Workplace>();
            String query = "SELECT workplace_name FROM workplaces WHERE user_id=" + id;
            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();
            MySqlDataReader datareader = command.ExecuteReader();

            while (datareader.Read())
            {
                
                String workplace_name = datareader["workplace_name"].ToString();

                Workplace newworkplace = new User.Workplace(id, workplace_name);
                Workplaces.Add(newworkplace);
            }


            datareader.Close();
            Database.connection_DB.Close();
            return Workplaces;
        }
        public void updateWorkplaces(string uid, string workname, string newworkname )
        {
            String query = String.Format("UPDATE workplaces SET workplace_name='{0}' WHERE user_id='{1}' AND workplace_name='{2}'", newworkname, uid, workname);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            command.ExecuteNonQuery();

            Database.connection_DB.Close();

        }
        public static Workplace InsertWork(string uid, string workplace_name)
        {
            int idtemp = Convert.ToInt32(uid);
            Formentry formentry = new Formentry();
            int x = formentry.Number;
            String query = String.Format("INSERT INTO workplaces (user_id, workplace_name) VALUES ('{0}', '{1}')", idtemp, workplace_name);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);

            formentry.Number++;
            Database.connection_DB.Open();
            command.ExecuteNonQuery();

            int id = (int)command.LastInsertedId;

            Workplace w = new Workplace(x, workplace_name);


            Database.connection_DB.Close();
            return w;

        }
        public void Deleteworkplace(string uid, string work)
        {
            int id = Convert.ToInt32(uid);
            String query = String.Format("DELETE FROM workplaces WHERE user_id='{0}' AND workplace_name='{1}' ", id, work);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
        public static List<User.University> getlistsofuniversities(String user_id)
        {
            int id = Convert.ToInt32(user_id);
            List<User.University> universities = new List<User.University>();
            String query = "SELECT university_name FROM universities WHERE user_id=" + id;
            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();
            MySqlDataReader datareader = command.ExecuteReader();

            while (datareader.Read())
            {
                
                String university_name = datareader["university_name"].ToString();

                User.University newuniversity = new User.University(id, university_name);
                universities.Add(newuniversity);
            }


            datareader.Close();
            Database.connection_DB.Close();
            return universities;
        }
        public static University InsertUniversity(string uid,string university_name)
        {
            Formentry formentry = new Formentry();
            int x = formentry.Number;
            int idtemp = Convert.ToInt32(uid);
            String query = String.Format("INSERT INTO universities (user_id, university_name) VALUES ('{0}', '{1}')", idtemp, university_name);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);

            formentry.Number++;
            Database.connection_DB.Open();
            command.ExecuteNonQuery();

            int id = (int)command.LastInsertedId;

            University u = new University(x, university_name);


            Database.connection_DB.Close();
            return u;

        }
        public void updateUniversity(string inuniversity_name)
        {
            String query = String.Format("UPDATE universities SET university_name='{0}' WHERE user_id='{1}'", inuniversity_name, User_ID);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            command.ExecuteNonQuery();

            Database.connection_DB.Close();

        }
        public void DeleteUniversity(string uid, string university_name)
        {
            int id = Convert.ToInt32(uid);
            String query = String.Format("DELETE FROM university WHERE user_id='{0}' AND university_name='{1}' ", id, university_name);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }


        // There we create a method which will read our data from Mysql database 
        // and put it to the list of users which will actually be an array of User class.
        // This method will return a list of users.
        public static List<User> getlistofUsers()
        {
            // Create a list of users
            List<User> Allusers = new List<User>();
            // create a string variable which will contain a SQL query, and create mysql command which will contain our SQL query 
            // in our mysql database we have a table facebook_users, from which we fetch our data  
            // There we create sql query SELECT ALL the syntaxis will be
            // SELECT * FROM table_name
            String Query = "SELECT * FROM facebook_users";
            MySqlCommand command = new MySqlCommand(Query, Database.connection_DB);
            // Open a database connection and start reading the data from there by declaring datareader variable
            Database.connection_DB.Open();
            MySqlDataReader datareader = command.ExecuteReader();

            // reading the database and creating a User to Allusers list 
            while (datareader.Read())
            {
                int id = (int)datareader["user_id"];
                String First_name = datareader["first_name"].ToString();
                String Last_name = datareader["last_name"].ToString();
                String Gender = datareader["gender"].ToString();
                String Hometown = datareader["hometown"].ToString();
                String City = datareader["city"].ToString();

                User newuser = new User(id, First_name, Last_name, Gender, Hometown, City);

                Allusers.Add(newuser);
            }
            // When we have read the data from a database table we finish our reading and close our connection
            datareader.Close();
            Database.connection_DB.Close();
            return Allusers;
        }
        // method that will update a user data
        public void UpdateUSER(string First_name, string Last_name, string Gender, string Hometown, string City)
        {
            String query = String.Format("UPDATE facebook_users SET first_name='{0}', last_name='{1}', gender='{2}', hometown='{3}', city='{4}' WHERE user_id='{5}'", First_name, Last_name, Gender, Hometown, City, User_ID);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            command.ExecuteNonQuery();

            Database.connection_DB.Close();

        }
        //this method will insert a new user to the database
        public static User InsertUser(string First_name, string Last_name, string Gender, string Hometown, string City)
        {
            Formentry formentry = new Formentry();
            int x = formentry.Number;

            // there we put our command in sql to insert a new user to a facebook_users table
            // the format is -- INSERT INTO table_name (column1 , column2 , column3, column4, ... ,columnN
            // VALUES ( value1, value2, value3, value4, ... , valuN)
            String query = String.Format("INSERT INTO facebook_users (user_id ,first_name, last_name, gender, hometown, city) VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}')", x ,First_name, Last_name, Gender, Hometown, City);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            
            formentry.Number++;
            Database.connection_DB.Open();
            command.ExecuteNonQuery();

            int id = (int)command.LastInsertedId;

            User user = new User(x, First_name, Last_name, Gender, Hometown, City);

           
            Database.connection_DB.Close();
            return user;
        }
       
        public void DeleteUser()
        {
            String query = String.Format("DELETE FROM facebook_users WHERE user_id='{0}' ", User_ID);

            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();


            command.ExecuteNonQuery();

            Database.connection_DB.Close();
        }

        public void getUserinfo(string uid)
        {
            int id = Convert.ToInt32(uid);
            string Query = "SELECT first_name, last_name FROM facebook_users WHERE user_id=" + id;
            MySqlCommand command = new MySqlCommand(Query, Database.connection_DB);
            MySqlDataReader reader = command.ExecuteReader();
            Database.connection_DB.Open();
            while (reader.Read())
            {
                string first_name = reader["first_name"].ToString();
                string last_name = reader["last_name"].ToString();
            }
            reader.Close();
            Database.connection_DB.Close();
        }
        public static List<Message> getlistofmessages(string user_id)
        {
            int id = Convert.ToInt32(user_id);
            string query = "SELECT facebook_users.user_id, facebook_users.first_name, facebook_users.last_name, messages.date_time, messages.messages FROM messages INNER JOIN facebook_users ON messages.user_id2 = facebook_users.user_id WHERE messages.user_id1 =" + id;
            List<Message> messages = new List<Message>();
            MySqlCommand command = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            MySqlDataReader dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                int idtemp = (int)dataReader["user_id"];
                string first_name = dataReader["first_name"].ToString();
                string last_name = dataReader["last_name"].ToString();
                string date_time = dataReader["date_time"].ToString();
                string message_text = dataReader["messages"].ToString();

                User.Message newmessage = new Message(id , idtemp, date_time, message_text);
                messages.Add(newmessage);
            }

            dataReader.Close();
            Database.connection_DB.Close();
            return messages;
        }
        public void DeleteMessage(string uid, string uid2, string date_time)
        {
            int id1 = Convert.ToInt32(uid);
            int id2 = Convert.ToInt32(uid2);
            String query = String.Format("DELETE FROM messages WHERE user_id1='{0}' AND user_id2='{1}' AND date_time='{2}'",id1,id2, date_time);
            MySqlCommand cmd = new MySqlCommand(query, Database.connection_DB);
            Database.connection_DB.Open();

            cmd.ExecuteNonQuery();

            Database.connection_DB.Close();
        }
    }
}
